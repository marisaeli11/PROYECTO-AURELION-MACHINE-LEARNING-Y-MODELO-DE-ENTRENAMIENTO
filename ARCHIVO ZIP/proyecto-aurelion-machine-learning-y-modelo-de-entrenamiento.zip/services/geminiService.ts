
import { GoogleGenAI } from "@google/genai";

// Initialize the API client
// NOTE: The API Key is expected to be available in process.env.API_KEY
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

export const getMentorExplanation = async (topic: string, contextData?: string): Promise<string> => {
    if (!apiKey) return "Error: API Key no encontrada.";

    const model = 'gemini-2.5-flash';
    const prompt = `
    Actúa como un Mentor Senior de Machine Learning para un estudiante llamado Aurelion.
    El proyecto es predecir la fidelidad del cliente usando Regresión Logística.
    
    El estudiante pregunta sobre: "${topic}".
    
    Datos de contexto (si los hay):
    ${contextData || 'Sin datos específicos.'}
    
    Explica el concepto de forma sencilla y en ESPAÑOL, usando el contexto de Aurelion (Clientes, métricas RFM).
    Si explicas métricas (Precisión/Recall), usa las clases específicas: Fiel (1) vs Ocasional (0).
    Mantén la respuesta concisa (menos de 150 palabras) pero alentadora.
    Usa formato Markdown.
    `;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text || "No se generó explicación.";
    } catch (error) {
        console.error("Gemini API Error:", error);
        return "Lo siento, no pude contactar al mentor en este momento. Revisa tu API key.";
    }
};

export const analyzeInsights = async (rfmSummary: string): Promise<string> => {
    if (!apiKey) return "Error: API Key not found.";
    
    const model = 'gemini-2.5-flash';
    const prompt = `
    Actúa como un Gerente de Estrategia Comercial presentando un reporte a la Directiva de Aurelion Retail.
    Basado en los siguientes datos reales (RFM):
    ${rfmSummary}
    
    Genera un Resumen Ejecutivo en un ESPAÑOL DE NEGOCIOS NATURAL.
    
    Reglas de Formato OBLIGATORIAS:
    1. Los números de dinero deben respetar el formato enviado (Punto para miles, Coma para decimales. Ej: $ 39.573,39).
    2. NO uses palabras forzadas como "robusto" o "salud de ingresos".
    3. NO uses markdown de listas (viñetas o asteriscos) dentro de las secciones, escribe párrafos.
    
    Estructura de la respuesta:
    
    ### 📊 Estatus de Cartera
    Describe la situación actual de fidelización y el Ticket Promedio usando los datos.
    
    ### 💡 Hallazgo Clave
    Escribe UNA sola frase contundente. 
    IMPORTANTE: DEBE comenzar obligatoriamente con la palabra "El". (Ejemplo: "El comportamiento de compra indica que...")
    
    ### 🚀 Estrategia Sugerida
    Una recomendación táctica clara para retener a los clientes.
    `;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text || "No insights generated.";
    } catch (error) {
        console.error("Gemini API Error:", error);
        return "Unable to generate insights.";
    }
};