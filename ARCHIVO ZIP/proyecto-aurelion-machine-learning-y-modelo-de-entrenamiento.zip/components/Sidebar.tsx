import React from 'react';
import { 
    LayoutDashboard, 
    Database, 
    Wand2, 
    BrainCircuit, 
    MessageSquare, 
    Code, 
    HelpCircle,
    Github
} from 'lucide-react';
import { AppView } from '../types';

interface SidebarProps {
    currentView: AppView;
    onChangeView: (view: AppView) => void;
    setShowHelpModal: (show: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, setShowHelpModal }) => {
    const navItems = [
        { id: AppView.CONTEXT, label: 'Contexto', icon: LayoutDashboard },
        { id: AppView.DATA_PREP, label: 'Datos y Limpieza', icon: Database },
        { id: AppView.FEATURE_ENGINEERING, label: 'Ingeniería Features', icon: Wand2 },
        { id: AppView.MODEL_EXPLAINER, label: 'Explicación Modelo', icon: BrainCircuit },
        { id: AppView.PYTHON_CODE, label: 'Notebook Python', icon: Code },
        { id: AppView.MENTOR, label: 'Mentor AI', icon: MessageSquare },
    ];

    return (
        <div className="w-64 bg-slate-900 h-screen fixed left-0 top-0 flex flex-col border-r border-slate-800 z-10">
            <div className="p-6 border-b border-slate-800 shrink-0">
                <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent leading-tight">
                    Proyecto Aurelion
                </h1>
                <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">ML y Entrenamiento</p>
            </div>
            
            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentView === item.id;
                    return (
                        <button
                            key={item.id}
                            onClick={() => onChangeView(item.id)}
                            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                                isActive 
                                ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' 
                                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                            }`}
                        >
                            <Icon size={20} />
                            <span className="text-sm font-medium">{item.label}</span>
                        </button>
                    );
                })}
            </nav>

            {/* Botón Crítico para Guardar */}
            <div className="p-4 border-t border-slate-800 bg-slate-900 shrink-0">
                <button 
                    onClick={() => setShowHelpModal(true)}
                    className="w-full p-3 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/50 rounded-lg text-left hover:bg-yellow-600/30 transition-all group cursor-pointer relative overflow-hidden"
                >
                    <div className="flex items-center gap-3 relative z-10">
                        <div className="bg-yellow-500 p-1.5 rounded-md text-slate-900">
                            <Github size={18} strokeWidth={2.5} />
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-0.5">IMPORTANTE</p>
                            <p className="text-xs font-bold text-white leading-tight">
                                ¿DÓNDE ESTÁ EL BOTÓN DE GITHUB?
                            </p>
                        </div>
                    </div>
                </button>
            </div>
        </div>
    );
};