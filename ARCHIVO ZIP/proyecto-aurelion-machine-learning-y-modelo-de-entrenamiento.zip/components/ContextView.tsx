import React from 'react';
import { Download, BrainCircuit, Cpu, Activity, HelpCircle, Grid, ListChecks, FileText, AlertTriangle } from 'lucide-react';

export const ContextView: React.FC = () => {

    const handleDownloadReadme = () => {
        const content = `# Proyecto Aurelion - Sprint 3: Clasificación de Fidelidad (Machine Learning)

## 📝 Inventario de Entrega
Este proyecto se compone de los siguientes archivos que deben estar en la misma carpeta para su correcta visualización en VS Code:

1.  **sprint3_aurelion_notebook.ipynb** (Notebook Principal)
2.  **master_rfm_aurelion_limpio.csv** (Dataset)
3.  **entrenamiento_modelo_aurelion.py** (Script de Entrenamiento)
4.  **grafico_distribucion_target.png** (Imagen)
5.  **grafico_frecuencia_vs_gasto.png** (Imagen)
6.  **grafico_frontera_decision.png** (Imagen)

---

## 1. Objetivo del Modelo
**Problema:** La tienda Aurelion tiene ventas constantes pero no identifica a sus clientes valiosos. Gastamos marketing en gente que no vuelve.
**Solución:** Un modelo de Machine Learning (Clasificación) que etiqueta a los clientes como **Fieles** o **Ocasionales** basándose en su comportamiento histórico.

---

## 2. Descripción del Dataset (X e y)

Para entrenar el modelo, dividimos la información en dos grupos. 

| Rol en ML | Variable | Definición (Qué representa) |
|-----------|----------|-----------------------------|
| **y (Target)** | \`is_fidelizado\` | **La Respuesta a predecir.** <br> 1 = Cliente Fiel (2+ compras). <br> 0 = Cliente Ocasional (1 compra). |
| **X (Excluido)** | \`frequency\` | **Variable de Negocio.** Define la fidelidad. **Se elimina del entrenamiento (X)** para evitar que el modelo memorice la regla. |
| **X (Feature)** | \`recency_days\` | **Variable Predictora.** Cantidad de días desde la última compra hasta hoy. |
| **X (Feature)** | \`monetary_log\` | **Variable Predictora.** Logaritmo del total gastado (usamos logaritmo para suavizar montos muy altos). |

### 🚨 Decisión Técnica: Prevención de Data Leakage
Durante el desarrollo, detectamos que incluir la variable \`frequency\` generaba un modelo con 100% de precisión artificial, lo cual indicaba una fuga de información (el modelo "leía" la regla de negocio en lugar de predecir).

**Acción Tomada:**
Decidimos eliminar \`frequency\` de las variables predictoras (X).

**¿Por qué?**
Queremos un modelo que pueda predecir si un cliente nuevo (con 1 sola compra) tiene potencial de ser fiel en el futuro, basándose únicamente en su perfil de gasto y recencia, sin esperar a que realice la segunda compra.

---

## 3. Ficha Técnica del Modelo

*   **Algoritmo:** Regresión Logística (\`LogisticRegression\`)
*   **Librería:** Scikit-Learn (Python)
*   **Tipo:** Clasificación Binaria Supervizada
*   **Optimizador (Solver):** \`liblinear\` (Ideal para datasets pequeños)
*   **Hiperparámetros:**
    *   Tasa de Aprendizaje: 0.01
    *   Iteraciones (Epochs): 100

### ¿Por qué Regresión Logística y no Lineal?
El profesor preguntará esto.
*   **Lineal:** Dibuja una recta. Predice números infinitos (ej: precio, temperatura).
*   **Logística:** Dibuja una "S". Predice **Probabilidad** (de 0 a 1). Como queremos clasificar "Sí/No", necesitamos la Logística.

---

## 4. Guía para la Demo (Los 10 Puntos)

| Punto Requerido | Dónde mostrarlo en VS Code |
|-----------------|----------------------------|
| 1. Objetivo | Ver Sección 1 de este README. |
| 2. Dataset (X e y) | Ver Sección 2 de este README (Tabla de Variables). |
| 3. Preprocesamiento | Notebook (Celda 3): \`StandardScaler\` y \`OneHotEncoder\`. |
| 4. División Train/Test | Notebook (Celda 4): \`train_test_split\`. |
| 5. Selección Algoritmo | Notebook: \`LogisticRegression\`. |
| 6. Entrenamiento | Notebook: \`.fit(X_train, y_train)\`. |
| 7. Predicciones | Notebook: \`.predict(X_test)\`. |
| 8. Métricas | Notebook: \`confusion_matrix\`, Accuracy 100%. |
| 9. Modelo Final | Script \`entrenamiento_modelo_aurelion.py\`. |
| 10. Gráficos | Ver Notebook o las imágenes adjuntas abajo. |

---

## 5. Visualización de Datos (Evidencia)

### Distribución del Target (Balance de clases)
![Distribución](./grafico_distribucion_target.png)

### Patrón de Comportamiento (Nuestras variables X)
![Patrón](./grafico_frecuencia_vs_gasto.png)

### Frontera de Decisión del Modelo
![Frontera](./grafico_frontera_decision.png)

---

## 6. Matriz de Confusión (Ayuda Memoria)

*   **TP (Verde):** La IA dijo "Fiel" y ACERTÓ.
*   **TN (Verde):** La IA dijo "Ocasional" y ACERTÓ.
*   **FP (Rojo - Error Tipo 1):** Dijo "Fiel" pero era Ocasional. (Gastamos dinero en vano).
*   **FN (Rojo - Error Tipo 2):** Dijo "Ocasional" pero era Fiel. (Perdimos un cliente VIP).
`;
        const blob = new Blob([content], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'README.md';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="space-y-6 pb-20">
            {/* Header Section */}
            <div className="bg-slate-900 text-white p-8 rounded-2xl shadow-xl border border-slate-700 relative overflow-hidden">
                <div className="relative z-10">
                    <div className="flex justify-between items-start">
                        <div>
                            <h2 className="text-3xl font-black mb-2 bg-gradient-to-r from-blue-400 to-teal-300 bg-clip-text text-transparent">
                                Contexto del Proyecto
                            </h2>
                            <p className="text-slate-400 max-w-xl text-sm leading-relaxed">
                                Documentación oficial para la defensa del Sprint 3. Este archivo <strong>README.md</strong> es tu portada en Visual Studio Code.
                            </p>
                        </div>
                        <button 
                            onClick={handleDownloadReadme}
                            className="bg-white text-slate-900 hover:bg-blue-50 px-6 py-3 rounded-xl font-bold text-sm shadow-lg transition-transform hover:scale-105 flex items-center gap-2"
                        >
                            <Download size={18} />
                            Descargar README.md
                        </button>
                    </div>
                </div>
                <div className="absolute right-0 top-0 opacity-10 p-4">
                    <FileText size={150} />
                </div>
            </div>

            {/* DATA LEAKAGE WARNING CARD */}
            <div className="bg-amber-50 p-6 rounded-xl shadow-sm border border-amber-200 border-l-4 border-l-amber-500">
                <h3 className="text-lg font-bold text-amber-900 mb-2 flex items-center gap-2">
                    <AlertTriangle className="text-amber-600" />
                    Nota Importante: Corrección de Data Leakage
                </h3>
                <p className="text-sm text-amber-800 mb-2">
                    <strong>¿Por qué eliminamos 'frequency' del entrenamiento?</strong>
                </p>
                <p className="text-sm text-amber-800 leading-relaxed">
                    Definimos que <em>"Fiel" = "Frecuencia ≥ 2"</em>. Si usamos la frecuencia como dato de entrada, el modelo "hace trampa" porque ya sabe la respuesta. 
                    Para el Sprint 3, hemos removido esta variable de las <strong>Features (X)</strong> para obligar al modelo a predecir basándose en otros patrones (Recencia, Gasto, etc.).
                </p>
            </div>

            {/* The 10 Points Guide Card */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <ListChecks className="text-blue-600" />
                    Guía de Defensa (Los 10 Puntos)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                        { id: 1, text: "Objetivo del Modelo", icon: Activity },
                        { id: 2, text: "Descripción Dataset (X e y)", icon: Grid },
                        { id: 3, text: "Preprocesamiento", icon: Cpu },
                        { id: 4, text: "División Train/Test", icon: Grid },
                        { id: 5, text: "Selección Algoritmo", icon: BrainCircuit },
                        { id: 6, text: "Entrenamiento .fit()", icon: Activity },
                        { id: 7, text: "Predicciones .predict()", icon: BrainCircuit },
                        { id: 8, text: "Métricas Evaluación", icon: ListChecks },
                        { id: 9, text: "Modelo Final implementado", icon: FileText },
                        { id: 10, text: "Gráficos y Conclusiones", icon: HelpCircle },
                    ].map((point) => (
                        <div key={point.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                            <div className="bg-white p-2 rounded-md shadow-sm text-slate-500 font-bold text-xs">
                                #{point.id}
                            </div>
                            <span className="text-sm text-slate-700 font-medium">{point.text}</span>
                        </div>
                    ))}
                </div>
                <div className="mt-4 p-3 bg-blue-50 text-blue-800 text-xs rounded-lg border border-blue-100">
                    <strong>Tip para VSC:</strong> Descarga el README.md arriba. Contiene esta tabla mapeada a los archivos reales para que no te pierdas durante la presentación.
                </div>
            </div>

            {/* Variables Explanation Card (X and Y) */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Grid className="text-indigo-600" />
                    Variables del Modelo (X e y)
                </h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-50">
                            <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Rol</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Variable</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Estatus</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                            <tr className="bg-indigo-50/50">
                                <td className="px-4 py-3 font-bold text-indigo-700">y (Target)</td>
                                <td className="px-4 py-3 font-mono text-slate-700">is_fidelizado</td>
                                <td className="px-4 py-3 text-slate-600">Objetivo (1=Fiel, 0=Ocasional)</td>
                            </tr>
                            <tr className="bg-red-50">
                                <td className="px-4 py-3 font-bold text-red-600">X (Excluido)</td>
                                <td className="px-4 py-3 font-mono text-red-700 line-through">frequency</td>
                                <td className="px-4 py-3 text-red-700 text-xs">
                                    <strong>ELIMINADO</strong> para evitar Data Leakage (Trampa).
                                </td>
                            </tr>
                            <tr>
                                <td className="px-4 py-3 font-bold text-slate-600">X (Feature)</td>
                                <td className="px-4 py-3 font-mono text-slate-700">recency_days</td>
                                <td className="px-4 py-3 text-slate-600">Input válido (Días sin venir)</td>
                            </tr>
                            <tr>
                                <td className="px-4 py-3 font-bold text-slate-600">X (Feature)</td>
                                <td className="px-4 py-3 font-mono text-slate-700">monetary_log</td>
                                <td className="px-4 py-3 text-slate-600">Input válido (Gasto Total Normalizado)</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};