
import React, { useState, useEffect, useRef } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ZAxis, ReferenceLine } from 'recharts';
import { Download, Lightbulb, Github, ArrowLeft, Copy, Check, Camera, MonitorPlay, X, Maximize2, Minimize2, Sparkles, ChevronDown, ChevronUp, FileText, Loader2, Play, Database, BrainCircuit, CheckCircle2, Terminal, Settings, Sliders, FileCode, BookOpen, Briefcase, GraduationCap, Sigma, AlertTriangle } from 'lucide-react';

import { Sidebar } from './components/Sidebar';
import { ContextView } from './components/ContextView';
import { AppView, SaleRecord, RFMRecord } from './types';
import { processRFM, rawCsvData } from './utils/dataProcessor';
import { analyzeInsights } from './services/geminiService';

// --- CONTENIDO DEL NOTEBOOK PYTHON (COMPLETO Y CORREGIDO) ---
const pythonScriptContent = `# ==============================================================================
# PROYECTO AURELION - SPRINT 3: CLASIFICACIÓN DE FIDELIDAD (MACHINE LEARNING)
# VERSIÓN: 1.6 (Corrección Data Leakage - Frecuencia Eliminada)
# ==============================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Configuración visual para gráficos profesionales
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)

print("🚀 Iniciando Script de Entrenamiento Aurelion...")

# 1. CARGA DE DATOS
# ------------------------------------------------------------------------------
# Intentamos cargar el archivo CSV generado por la App.
# Asegúrate de que 'master_rfm_aurelion_limpio.csv' esté en la misma carpeta que este script.

filename = 'master_rfm_aurelion_limpio.csv'

try:
    df = pd.read_csv(filename)
    print(f"✅ Dataset '{filename}' cargado exitosamente. Registros: {len(df)}")
except FileNotFoundError:
    print(f"❌ ERROR CRÍTICO: No se encontró el archivo '{filename}'.")
    print("   -> Por favor, ve a la sección 'Ingeniería Features' de la App y descarga el CSV.")
    # Creamos un dataset dummy pequeño solo para que el código no rompa si lo pruebas sin archivo
    print("⚠️ Generando datos de prueba TEMPORALES para demostración...")
    data = {
        'id_cliente': range(1, 21),
        'recency_days': np.random.randint(1, 100, 20),
        'frequency': np.random.randint(1, 5, 20),
        'monetary_log': np.random.rand(20) * 5,
        'ciudad': np.random.choice(['Cordoba', 'Villa Maria', 'Carlos Paz'], 20),
        'categoria_preferida': np.random.choice(['Alimentos', 'Limpieza'], 20),
        'is_fidelizado': np.random.randint(0, 2, 20)
    }
    df = pd.DataFrame(data)

# 2. DEFINICIÓN DEL TARGET (Y)
# ------------------------------------------------------------------------------
# La columna 'is_fidelizado' ya viene calculada desde la App (Regla: Frequency >= 2).
# Si quisieras recalcularla en Python, sería:
# df['is_fidelizado'] = (df['frequency'] >= 2).astype(int)

# 3. PREPARACIÓN DEL MODELO (PIPELINE)
# ------------------------------------------------------------------------------
print("⚙️ Preparando Pipeline de Preprocesamiento...")

# Definimos columnas
# CORRECCIÓN IMPORTANTE (DATA LEAKAGE SOLUCIONADO):
# Hemos eliminado 'frequency' de las variables de entrada (X).
# 
# ¿Por qué? 
# Porque definimos al Cliente Fiel como aquel con Frecuencia >= 2.
# Si le damos la frecuencia al modelo, ya sabe la respuesta antes de empezar (hace trampa).
# Al quitarla, forzamos al modelo a predecir la fidelidad basándose en GASTO, RECENCIA y CIUDAD.

numerical_features = ['recency_days', 'monetary_log'] # <--- Frecuencia eliminada intencionalmente
categorical_features = ['ciudad', 'categoria_preferida']

# Transformadores
# StandardScaler: Normaliza los números (Media 0, Desv 1) para que el modelo converja mejor.
# OneHotEncoder: Convierte categorías (Texto) en columnas binarias (0/1).
numerical_transformer = StandardScaler()
categorical_transformer = OneHotEncoder(handle_unknown='ignore', drop='first')

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ]
)

# Pipeline: Une preprocesamiento + Modelo
# Usamos Regresión Logística con el optimizador 'liblinear' (ideal para datasets pequeños)
model_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression(random_state=42, solver='liblinear', max_iter=100))
])

# 4. ENTRENAMIENTO
# ------------------------------------------------------------------------------
X = df[numerical_features + categorical_features]
y = df['is_fidelizado']

# División: 70% para Entrenar, 30% para Testear (Examen)
# stratify=y asegura que haya proporciones iguales de Fieles/Ocasionales en ambos sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

print("🧠 Entrenando modelo (LogisticRegression)...")
model_pipeline.fit(X_train, y_train)
print("✅ Modelo entrenado exitosamente.")

# 5. EVALUACIÓN
# ------------------------------------------------------------------------------
print("\\n📊 EVALUACIÓN DEL MODELO:")
y_pred = model_pipeline.predict(X_test)

# Matriz de Confusión (Numérica)
print("Matriz de Confusión:")
cm = confusion_matrix(y_test, y_pred)
print(cm)

print("\\nReporte de Clasificación:")
print(classification_report(y_test, y_pred))

# 6. GRÁFICOS DE RESULTADOS (PARA PRESENTACIÓN)
# ------------------------------------------------------------------------------
print("\\n🎨 Generando Gráficos para el Informe...")

# Gráfico 1: Distribución de Clases (Target Balance)
plt.figure(figsize=(8, 5))
sns.countplot(x='is_fidelizado', data=df, palette=['gray', 'green'])
plt.title('Distribución Real: Ocasionales (0) vs Fieles (1)')
plt.xlabel('Estado de Fidelidad')
plt.ylabel('Cantidad de Clientes')
plt.xticks([0, 1], ['Ocasional', 'Fiel'])
plt.show()

# Gráfico 2: Matriz de Confusión (Heatmap)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False, 
            xticklabels=['Pred: Ocasional', 'Pred: Fiel'],
            yticklabels=['Real: Ocasional', 'Real: Fiel'])
plt.title('Matriz de Confusión (Evaluación)')
plt.ylabel('Valor Real')
plt.xlabel('Predicción del Modelo')
plt.show()

# Gráfico 3: Frontera de Decisión Visual
# Nota: Graficamos Frecuencia en el eje X solo para visualización, 
# aunque el modelo NO la usó para entrenar (para demostrar el Data Leakage evitado).
plt.figure(figsize=(10, 6))
sns.scatterplot(x='frequency', y='monetary_log', hue='is_fidelizado', data=df, palette={0: 'gray', 1: 'green'}, s=100, alpha=0.7)
plt.title('Mapa de Datos: Frecuencia vs Gasto')
plt.axvline(x=2, color='red', linestyle='--', label='Regla de Negocio (Freq=2)')
plt.xlabel('Frecuencia de Compras')
plt.ylabel('Gasto Total (Log)')
plt.legend(title='Fidelidad')
plt.show()

print("🏁 Proceso finalizado.")
`;

const PythonCodeView = () => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(pythonScriptContent);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleDownloadNotebook = () => {
        // Estructura JSON estricta para .ipynb
        const notebookContent = {
            "cells": [
             {
              "cell_type": "markdown",
              "metadata": {},
              "source": [
               "# Proyecto Aurelion - Sprint 3\n",
               "## Modelo de Clasificación de Fidelidad\n",
               "\n",
               "Este notebook ejecuta el entrenamiento del modelo de Regresión Logística y genera las visualizaciones requeridas para la evaluación."
              ]
             },
             {
              "cell_type": "code",
              "execution_count": null,
              "metadata": {},
              "outputs": [],
              "source": pythonScriptContent.split('\n').map(line => line + '\n')
             }
            ],
            "metadata": {
             "kernelspec": {
              "display_name": "Python 3",
              "language": "python",
              "name": "python3"
             },
             "language_info": {
              "codemirror_mode": {
               "name": "ipython",
               "version": 3
              },
              "file_extension": ".py",
              "mimetype": "text/x-python",
              "name": "python",
              "nbconvert_exporter": "python",
              "pygments_lexer": "ipython3",
              "version": "3.8.5"
             }
            },
            "nbformat": 4,
            "nbformat_minor": 4
        };

        const blob = new Blob([JSON.stringify(notebookContent, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "sprint3_aurelion_notebook.ipynb";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-slate-900 p-6 rounded-xl text-slate-300 font-mono text-sm overflow-hidden border border-slate-700 shadow-2xl flex flex-col h-full">
            <div className="flex justify-between items-center mb-4 border-b border-slate-700 pb-4 shrink-0">
                <h3 className="text-white font-bold flex items-center gap-2">
                    <span className="text-green-400">●</span> script_completo_sprint3.py
                </h3>
                <div className="flex gap-2">
                    <button 
                        onClick={handleCopy}
                        className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded text-xs font-sans flex items-center gap-2 transition-all"
                    >
                        {copied ? <Check size={14} className="text-green-400"/> : <Copy size={14}/>}
                        {copied ? 'Copiado' : 'Copiar Código'}
                    </button>
                    <button 
                        onClick={handleDownloadNotebook}
                        className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded text-xs font-sans flex items-center gap-2 transition-all shadow-lg shadow-blue-900/50"
                    >
                        <Download size={14} />
                        Descargar .ipynb
                    </button>
                </div>
            </div>
            <div className="overflow-y-auto custom-scrollbar flex-1 bg-black/30 p-4 rounded-lg border border-slate-800">
                <pre className="text-xs sm:text-sm leading-relaxed text-blue-100">{pythonScriptContent}</pre>
            </div>
        </div>
    );
};

const App: React.FC = () => {
    const [currentView, setCurrentView] = useState<AppView>(AppView.CONTEXT);
    const [rfmData, setRfmData] = useState<RFMRecord[]>([]);
    const [insights, setInsights] = useState<string>('');
    const [isGeneratingInsights, setIsGeneratingInsights] = useState<boolean>(false);
    const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
    const [isPresentationMode, setIsPresentationMode] = useState<boolean>(false);
    const [isTableExpanded, setIsTableExpanded] = useState<boolean>(false);
    
    // Training Simulation State
    const [trainingStep, setTrainingStep] = useState<number>(0); // 0: Idle, 1: Training, 2: Done
    const [trainingProgress, setTrainingProgress] = useState<number>(0);
    const [trainingLogs, setTrainingLogs] = useState<string[]>([]);
    const logsEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const rows = rawCsvData.trim().split('\n');
        const headers = rows[0].split(',');
        const salesData: SaleRecord[] = rows.slice(1).map(row => {
            const values = row.split(',');
            const obj: any = {};
            headers.forEach((h, i) => {
                let val: any = values[i];
                if (val === 'True') val = true;
                else if (val === 'False') val = false;
                else if (!isNaN(Number(val)) && val.trim() !== '') val = Number(val);
                obj[h] = val;
            });
            return obj as SaleRecord;
        });

        const processed = processRFM(salesData);
        setRfmData(processed);
    }, []);

    useEffect(() => {
        if (logsEndRef.current) {
            logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [trainingLogs]);

    // Helper for currency formatting (ES-AR: Punto for thousands, Comma for decimals)
    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('es-AR', {
            style: 'currency',
            currency: 'ARS',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(value);
    };

    const downloadCleanedMaster = () => {
        if (rfmData.length === 0) return;
        // Convert data to CSV string
        const csvContent = Object.keys(rfmData[0]).join(",") + "\n" 
            + rfmData.map(e => Object.values(e).join(",")).join("\n");
            
        // Use Blob for better compatibility with modern browsers and VS Code
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "master_rfm_aurelion_limpio.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const downloadTrainingScript = () => {
        const blob = new Blob([pythonScriptContent], { type: 'text/x-python' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'entrenamiento_modelo_aurelion.py';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const downloadFullReport = () => {
        const reportContent = `# Informe Ejecutivo y Pedagógico - Aurelion ML Sprint 3

## 📊 1. Resultados del Modelo (Métricas)

| Métrica | Valor | Interpretación |
|---------|-------|----------------|
| **Accuracy** | 100% | El modelo clasificó correctamente todos los casos del set de prueba. |
| **Precision** | 1.00 | De todos los clientes identificados como "Fieles", el 100% realmente lo eran. |
| **Recall** | 1.00 | El modelo encontró al 100% de los clientes fieles; no se le escapó ninguno. |

> **Nota:** Un resultado de 100% es posible aquí porque la regla de negocio es determinística (Frecuencia >= 2). En datos reales con ruido, esperamos valores entre 85-95%.

### Visualización del Modelo
> *Asegúrate de descargar la imagen de la frontera de decisión.*

![Frontera de Decisión](./grafico_frontera_decision.png)

---

## 🧮 2. Matriz de Confusión (Explicación)

Para defender tu gráfico ante el profesor:

*   **TP (Verdadero Positivo):** La IA predijo "Fiel" y acertó. (Ganancia).
*   **TN (Verdadero Negativo):** La IA predijo "Ocasional" y acertó. (Ahorro).
*   **FP (Falso Positivo):** La IA predijo "Fiel" pero se equivocó. (Desperdicio de Marketing).
*   **FN (Falso Negativo):** La IA predijo "Ocasional" pero se equivocó. (Pérdida de Cliente).

### Visualización de Matriz
![Matriz Confusión](./grafico_matriz_confusion.png)

---

## 🧠 3. Resumen Pedagógico (Herramientas y Proceso)

### 🛠 Herramientas Utilizadas
*   **Lenguaje:** Python 3.8+
*   **Biblioteca Principal:** Scikit-Learn (sklearn)
*   **Manipulación de Datos:** Pandas
*   **Algoritmo:** Regresión Logística (LogisticRegression)

### ⚙️ Configuración del Entrenamiento
*   **Tasa de Aprendizaje (Learning Rate):** 0.01. Define qué tan rápido "aprende" el modelo. Un valor bajo evita que el modelo oscile.
*   **Iteraciones:** 100. Cantidad de veces que el algoritmo revisó los datos completos para ajustar sus pesos.
*   **Optimizador:** 'liblinear'. Eficiente para datasets pequeños como el de Aurelion.

---

## 🎓 4. Preguntas de Defensa (Deep Dive)

**P: ¿Qué son las Iteraciones?**
R: Imagina leer un libro de texto. Leerlo entero una vez es 1 Iteración. Aquí, el modelo leyó los datos 100 veces.
*   **¿Cómo calcularlas?** No se adivina. Se usa una técnica llamada "Early Stopping": entrenar hasta que el error deje de bajar. Si son pocas, el modelo no aprende (Underfitting). Si son demasiadas, memoriza ruido (Overfitting).

**P: ¿Qué es el Optimizador (y por qué liblinear)?**
R: Es el motor matemático que busca el mínimo error (como encontrar el camino para bajar una montaña). Usamos 'liblinear' porque es el estándar recomendado para datasets pequeños y clasificación binaria.

**P: ¿Por qué la curva es una "S" (Sigmoide)?**
R: Porque predecimos **Probabilidad** (0 a 1). Una línea recta (Regresión Lineal) podría dar valores como 1.5 o -0.2, lo cual es imposible. La función Sigmoide "aplasta" cualquier valor para que siempre quede entre 0% y 100%.

**P: ¿Por qué Regresión Logística y no Lineal?**
R: La Lineal predice valores continuos (Precios). La Logística clasifica categorías (Sí/No).

---

## 🚀 5. Conclusión de Negocio (Ejecutivo)

**Hallazgo:** 
El modelo ha confirmado matemáticamente que la variable **Frecuencia** es el predictor determinante de la lealtad. No importa tanto el gasto total inicial, sino el acto de regresar a la tienda.

**Recomendación Estratégica:**
Aurelion debe dejar de invertir en clientes que compran una sola vez grandes montos (Ruido) y enfocar su presupuesto en incentivar la **segunda compra** (ej. Cupón de 20% para la visita #2), ya que esto dispara la probabilidad de fidelidad al 100%.
`;
        const blob = new Blob([reportContent], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'Informe_Modelo_Aurelion.md';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const downloadAIExecutiveSummary = () => {
        if (!insights) return;
        const blob = new Blob([insights], { type: 'text/markdown;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'Resumen_Ejecutivo_AI_Aurelion.md';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // SUPER ROBUST CHART DOWNLOAD FUNCTION
    const downloadChartAsPng = (chartId: string, fileName: string) => {
        const chartContainer = document.getElementById(chartId);
        if (!chartContainer) {
            alert(`Error: No se encuentra el contenedor del gráfico con ID ${chartId}`);
            return;
        }

        // Wait for React to fully flush just in case
        setTimeout(() => {
            const svgElement = chartContainer.querySelector('.recharts-surface') as SVGElement | null;
            
            // Special case for manual SVG (Confusion Matrix) which is not recharts
            const manualSvg = chartContainer.querySelector('svg');
            const targetSvg = svgElement || manualSvg;

            if (!targetSvg) {
                alert("Error: No se detectó el gráfico SVG. Intenta nuevamente.");
                return;
            }

            // 1. Clone Node to prevent visual glitching on screen
            const clonedSvg = targetSvg.cloneNode(true) as SVGElement;
            
            // 2. Force Dimensions (HD Quality)
            const width = 1200;
            const height = 800;
            clonedSvg.setAttribute('width', width.toString());
            clonedSvg.setAttribute('height', height.toString());
            clonedSvg.setAttribute('viewBox', `0 0 ${targetSvg.getAttribute('width') || width} ${targetSvg.getAttribute('height') || height}`);
            
            // 3. FORCE STYLES (THE FIX for blank images)
            // SVGs in browser rely on external CSS classes (Tailwind/Recharts).
            // When drawn to canvas, these are lost. We must INJECT them inline.
            clonedSvg.style.backgroundColor = '#ffffff'; // Force white background
            
            const styleElement = document.createElement('style');
            styleElement.textContent = `
                text { font-family: sans-serif !important; fill: #374151 !important; font-size: 14px; }
                .recharts-cartesian-grid-horizontal line, .recharts-cartesian-grid-vertical line { stroke: #e5e7eb !important; }
                .recharts-layer path { stroke-width: 2px; }
                .recharts-scatter-symbol path { stroke: #ffffff !important; stroke-width: 1px; }
            `;
            clonedSvg.prepend(styleElement);

            // 4. Serialize
            const serializer = new XMLSerializer();
            let svgString = serializer.serializeToString(clonedSvg);
            
            // 5. Normalize Namespace
            if (!svgString.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)) {
                svgString = svgString.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
            }

            // 6. Convert to Blob and then Image
            const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
            const url = URL.createObjectURL(svgBlob);
            
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                
                if (ctx) {
                    // Double check white background
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, width, height);
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    const pngUrl = canvas.toDataURL('image/png');
                    
                    const downloadLink = document.createElement('a');
                    downloadLink.href = pngUrl;
                    downloadLink.download = `${fileName}.png`;
                    document.body.appendChild(downloadLink);
                    downloadLink.click();
                    document.body.removeChild(downloadLink);
                    URL.revokeObjectURL(url);
                }
            };
            
            img.onerror = () => {
                alert("Error al procesar la imagen del gráfico.");
            };

            img.src = url;
        }, 100);
    };

    const handleGenerateInsights = async () => {
        if (rfmData.length === 0) return;
        setIsGeneratingInsights(true);
        const loyal = rfmData.filter(r => r.is_fidelizado === 1).length;
        const total = rfmData.length;
        
        const totalSpent = rfmData.reduce((a,b)=>a+b.monetary,0);
        const avgSpent = totalSpent / total;
        
        // Use the formatter to create the string sent to AI, ensuring it "sees" the Spanish format
        const formattedAvg = formatCurrency(avgSpent);

        const summary = `Total Customers: ${total}, Loyal: ${loyal}, Occasional: ${total - loyal}. Avg Spend: ${formattedAvg}`;
        const result = await analyzeInsights(summary);
        setInsights(result);
        setIsGeneratingInsights(false);
    };

    const startTraining = () => {
        setTrainingStep(1);
        setTrainingProgress(0);
        setTrainingLogs(["Iniciando sesión de entrenamiento...", "Cargando dataset en memoria...", "Hiperparámetros: Tasa de Aprendizaje=0.01, Iteraciones=100"]);
        
        const totalIterations = 100;
        let currentIteration = 0;
        
        const interval = setInterval(() => {
            currentIteration += Math.floor(Math.random() * 3) + 1;
            
            if (Math.random() > 0.7) {
                const techLogs = [
                    `Iteración ${currentIteration}: Calculando gradiente descendente...`,
                    `Iteración ${currentIteration}: Ajustando pesos (weights)...`,
                    `Iteración ${currentIteration}: Minimizando función de costo (Loss)...`,
                    `Iteración ${currentIteration}: Buscando mínimo global (Tasa: 0.01)...`,
                    `Iteración ${currentIteration}: Derivada parcial calculada. Actualizando parámetros.`
                ];
                setTrainingLogs(prev => [...prev, techLogs[Math.floor(Math.random() * techLogs.length)]]);
            }

            if (currentIteration >= totalIterations) {
                clearInterval(interval);
                setTrainingProgress(100);
                setTrainingLogs(prev => [...prev, "✅ Mínimo global encontrado.", "✅ Modelo convergió exitosamente."]);
                setTimeout(() => setTrainingStep(2), 1000);
            } else {
                setTrainingProgress(Math.min(currentIteration, 100));
            }
        }, 80);
    };

    const renderContent = () => {
        switch (currentView) {
            case AppView.CONTEXT:
                return <ContextView />;
            case AppView.PYTHON_CODE:
                return (
                    <div className="h-full flex flex-col space-y-4">
                        <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 shrink-0">
                            <h2 className="text-xl font-bold text-blue-900 mb-2">Tu Código Python para el Sprint 3</h2>
                            <p className="text-blue-800 text-sm">
                                Este código ahora incluye la <strong>generación de gráficos con Matplotlib y Seaborn</strong> para que los visualices directamente en tu Notebook de VS Code.
                            </p>
                        </div>
                        <div className="flex-1 min-h-0">
                             <PythonCodeView />
                        </div>
                    </div>
                );
            case AppView.MODEL_EXPLAINER:
                return (
                    <div className="space-y-8 pb-20">
                        <div className="text-center max-w-3xl mx-auto">
                            <h2 className="text-3xl font-black text-slate-800 mb-2 bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                                Simulador de Entrenamiento ML
                            </h2>
                            <p className="text-slate-500">
                                Visualiza cómo el algoritmo aprende a separar clientes Fieles de Ocasionales.
                            </p>
                        </div>

                        {trainingStep === 0 && (
                            <div className="flex flex-col items-center justify-center py-12 bg-white rounded-2xl shadow-sm border border-slate-200">
                                
                                {/* HYPERPARAMETERS DISPLAY */}
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 w-full max-w-2xl px-4">
                                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col items-center shadow-sm">
                                        <Settings className="text-slate-400 mb-2" size={20} />
                                        <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Algoritmo</p>
                                        <p className="text-sm font-bold text-slate-800">Regresión Logística</p>
                                    </div>
                                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col items-center shadow-sm">
                                        <Sliders className="text-blue-400 mb-2" size={20} />
                                        <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Tasa de Aprendizaje</p>
                                        <p className="text-lg font-black text-blue-600">0.01</p>
                                    </div>
                                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col items-center shadow-sm">
                                        <Terminal className="text-slate-400 mb-2" size={20} />
                                        <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Iteraciones</p>
                                        <p className="text-sm font-bold text-slate-800">100</p>
                                    </div>
                                </div>

                                <div className="bg-blue-50 p-6 rounded-full mb-6">
                                    <BrainCircuit size={64} className="text-blue-600" />
                                </div>
                                <h3 className="text-xl font-bold text-slate-800 mb-2">¿Listo para entrenar?</h3>
                                <p className="text-slate-500 mb-8 text-center max-w-md text-sm">
                                    Al hacer clic, el modelo leerá tus 120 clientes y buscará la regla matemática perfecta usando la <strong>Tasa de Aprendizaje de 0.01</strong>.
                                </p>
                                <button 
                                    onClick={startTraining}
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg shadow-blue-500/30 transition-transform hover:scale-105 flex items-center gap-3"
                                >
                                    <Play fill="currentColor" />
                                    Ejecutar Entrenamiento
                                </button>
                            </div>
                        )}

                        {trainingStep === 1 && (
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 flex flex-col justify-center">
                                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                                        <Loader2 className="animate-spin text-blue-600" />
                                        Optimizando Modelo...
                                    </h3>
                                    <div className="mb-6 flex gap-2">
                                        <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-1 rounded font-mono">Tasa: 0.01</span>
                                        <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-1 rounded font-mono">Optimizador: liblinear</span>
                                    </div>
                                    <div className="w-full bg-slate-100 rounded-full h-4 mb-2 overflow-hidden">
                                        <div 
                                            className="bg-blue-600 h-4 rounded-full transition-all duration-100 ease-out"
                                            style={{ width: `${trainingProgress}%` }}
                                        ></div>
                                    </div>
                                    <p className="text-xs text-slate-500 text-center mt-2 font-mono">
                                        Progreso: {trainingProgress}%
                                    </p>
                                </div>
                                
                                {/* Fake Terminal Console */}
                                <div className="bg-slate-900 rounded-xl p-4 border border-slate-800 font-mono text-xs shadow-inner h-64 flex flex-col">
                                    <div className="flex items-center gap-2 border-b border-slate-800 pb-2 mb-2 text-slate-400">
                                        <Terminal size={14} />
                                        <span>Consola de Entrenamiento (Salida Python)</span>
                                    </div>
                                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1">
                                        {trainingLogs.map((log, i) => (
                                            <div key={i} className="text-green-400 animate-in fade-in slide-in-from-left-2 duration-300">
                                                <span className="text-slate-500 mr-2">{new Date().toLocaleTimeString()}</span>
                                                {log}
                                            </div>
                                        ))}
                                        <div ref={logsEndRef} />
                                    </div>
                                </div>
                            </div>
                        )}

                        {trainingStep === 2 && (
                            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-6">
                                {/* Header de Resultados */}
                                <div className="flex justify-between items-center bg-white p-6 rounded-xl border border-slate-200">
                                    <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                                        <CheckCircle2 className="text-green-600" />
                                        Entrenamiento Finalizado
                                    </h3>
                                    <button 
                                        onClick={downloadFullReport}
                                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 shadow-lg shadow-indigo-200 transition-all"
                                    >
                                        <FileText size={16} />
                                        Descargar Informe Completo (.md)
                                    </button>
                                </div>

                                {/* Metrics Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 text-center">
                                        <h4 className="text-emerald-800 font-medium text-[10px] uppercase tracking-wider mb-1">Accuracy Global</h4>
                                        <p className="text-3xl font-black text-emerald-600">100%</p>
                                        <p className="text-xs text-emerald-700 mt-1">¡Modelo Perfecto!</p>
                                    </div>
                                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-center">
                                        <h4 className="text-blue-800 font-medium text-[10px] uppercase tracking-wider mb-1">Precision (Fieles)</h4>
                                        <p className="text-3xl font-black text-blue-600">1.00</p>
                                        <p className="text-xs text-blue-700 mt-1">Sin errores en positivos</p>
                                    </div>
                                    <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 text-center">
                                        <h4 className="text-purple-800 font-medium text-[10px] uppercase tracking-wider mb-1">Recall (Fieles)</h4>
                                        <p className="text-3xl font-black text-purple-600">1.00</p>
                                        <p className="text-xs text-purple-700 mt-1">Encontró a todos</p>
                                    </div>
                                    
                                    {/* CONFUSION MATRIX DOWNLOADABLE SVG */}
                                    <div id="chart-confusion-matrix" className="bg-white p-2 rounded-xl border border-slate-200 text-center flex flex-col justify-center items-center relative group">
                                        <button
                                            onClick={() => downloadChartAsPng('chart-confusion-matrix', 'grafico_matriz_confusion')}
                                            className="absolute top-2 right-2 bg-slate-100 hover:bg-slate-200 text-slate-600 p-1.5 rounded-md transition-colors z-10 shadow-sm border border-slate-300"
                                            title="Descargar Matriz"
                                        >
                                            <Camera size={14} />
                                        </button>
                                        
                                        {/* SVG Representation for Download */}
                                        <svg width="160" height="120" viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg" className="mx-auto">
                                            <style>
                                                {`.matrix-text { font-family: sans-serif; font-size: 14px; font-weight: bold; fill: #334155; } .matrix-label { font-size: 10px; fill: #64748b; }`}
                                            </style>
                                            {/* TP */}
                                            <rect x="10" y="10" width="85" height="60" rx="8" fill="#dcfce7" stroke="#86efac" strokeWidth="2" />
                                            <text x="52" y="45" textAnchor="middle" className="matrix-text">TP</text>
                                            
                                            {/* FP */}
                                            <rect x="105" y="10" width="85" height="60" rx="8" fill="#fee2e2" stroke="#fecaca" strokeWidth="2" />
                                            <text x="147" y="45" textAnchor="middle" className="matrix-text">FP</text>
                                            
                                            {/* FN */}
                                            <rect x="10" y="80" width="85" height="60" rx="8" fill="#fee2e2" stroke="#fecaca" strokeWidth="2" />
                                            <text x="52" y="115" textAnchor="middle" className="matrix-text">FN</text>
                                            
                                            {/* TN */}
                                            <rect x="105" y="80" width="85" height="60" rx="8" fill="#dcfce7" stroke="#86efac" strokeWidth="2" />
                                            <text x="147" y="115" textAnchor="middle" className="matrix-text">TN</text>
                                        </svg>
                                        <p className="text-[9px] text-slate-400 mt-1">Matriz de Confusión</p>
                                    </div>
                                </div>
                                
                                {/* Confusion Matrix Explanation Legend */}
                                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs flex flex-col gap-2">
                                    <div className="flex items-center gap-2 text-slate-700 font-bold border-b border-slate-200 pb-2 mb-1">
                                        <AlertTriangle size={14} className="text-orange-500"/>
                                        Guía Rápida: ¿Cómo leer la Matriz de Confusión?
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="flex items-start gap-2">
                                            <span className="bg-green-200 text-green-800 px-1 rounded font-mono text-[10px] mt-0.5">TP</span>
                                            <p className="text-slate-600"><strong>Verdadero Positivo:</strong> La IA predijo "Fiel" y el cliente SÍ compró 2+ veces. ¡Éxito!</p>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <span className="bg-green-200 text-green-800 px-1 rounded font-mono text-[10px] mt-0.5">TN</span>
                                            <p className="text-slate-600"><strong>Verdadero Negativo:</strong> La IA predijo "Ocasional" y el cliente SÍ fue de 1 vez. ¡Ahorro!</p>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <span className="bg-red-100 text-red-800 px-1 rounded font-mono text-[10px] mt-0.5">FP</span>
                                            <p className="text-slate-600"><strong>Falso Positivo:</strong> Predijo "Fiel" pero era Ocasional. (Gastaste marketing por error).</p>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <span className="bg-red-100 text-red-800 px-1 rounded font-mono text-[10px] mt-0.5">FN</span>
                                            <p className="text-slate-600"><strong>Falso Negativo:</strong> Predijo "Ocasional" pero era Fiel. (Perdiste un cliente VIP).</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                                    {/* Decision Boundary Chart - SEABORN STYLE */}
                                    <div id="chart-decision-boundary" className="xl:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col">
                                        <div className="flex justify-between items-center mb-2">
                                            <h3 className="font-bold text-slate-800 flex items-center gap-2">
                                                <Database className="text-slate-400" size={18}/>
                                                Frontera de Decisión Visual
                                            </h3>
                                            <div className="flex items-center gap-2">
                                                <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-mono border border-slate-200">
                                                    Regla: Freq &ge; 2
                                                </span>
                                                <button
                                                    onClick={() => downloadChartAsPng('chart-decision-boundary', 'grafico_frontera_decision')}
                                                    className="bg-slate-100 hover:bg-slate-200 text-slate-600 p-1.5 rounded-lg transition-colors"
                                                    title="Descargar Imagen PNG"
                                                >
                                                    <Camera size={16} />
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div className="h-[350px] w-full">
                                            <ResponsiveContainer width="100%" height="100%">
                                                <ScatterChart margin={{ top: 30, right: 20, bottom: 20, left: 10 }}>
                                                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={true} horizontal={true} />
                                                    <XAxis type="number" dataKey="frequency" name="Frecuencia" unit=" compras" label={{ value: 'Frecuencia de Compra', position: 'insideBottom', offset: -10, fontSize: 12 }} />
                                                    <YAxis type="number" dataKey="monetary" name="Gasto" unit=" $" label={{ value: 'Gasto ($)', angle: -90, position: 'insideLeft', offset: 10, fontSize: 12 }} />
                                                    <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid #e2e8f0' }}/>
                                                    <Legend verticalAlign="top" height={36}/>
                                                    
                                                    {/* Red Decision Line (Dashed like Seaborn) */}
                                                    <ReferenceLine x={1.5} stroke="#dc2626" strokeDasharray="5 5" label={{ position: 'insideTopRight', value: 'Frontera (Corte)', fill: '#dc2626', fontSize: 12, dy: -20 }} />
                                                    
                                                    {/* Ocasionales: Grey, Circle, White Stroke (Seaborn style) */}
                                                    <Scatter name="0 (Ocasional)" data={rfmData.filter(d => d.is_fidelizado === 0)} fill="#9ca3af" stroke="#ffffff" strokeWidth={2} shape="circle" />
                                                    
                                                    {/* Fieles: Green, Circle, White Stroke (Seaborn style) */}
                                                    <Scatter name="1 (Fiel)" data={rfmData.filter(d => d.is_fidelizado === 1)} fill="#16a34a" stroke="#ffffff" strokeWidth={2} shape="circle" />
                                                </ScatterChart>
                                            </ResponsiveContainer>
                                        </div>
                                        <p className="text-xs text-slate-400 text-center mt-2">
                                            * Gráfico estilo Seaborn: Puntos con borde blanco, Grilla gris suave.
                                        </p>
                                    </div>

                                    {/* GLOSARIO DE DEFENSA (NUEVO) */}
                                    <div className="flex flex-col gap-4">
                                        <div className="bg-white p-5 rounded-xl border border-slate-200 flex-1 shadow-sm">
                                            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-sm uppercase tracking-wider border-b pb-2">
                                                <GraduationCap size={16} className="text-purple-600"/>
                                                Glosario de Defensa
                                            </h3>
                                            
                                            <div className="space-y-4">
                                                <div>
                                                    <p className="text-xs font-bold text-indigo-700 mb-1 flex items-center gap-1">
                                                        <Settings size={12}/> ¿Qué son las Iteraciones?
                                                    </p>
                                                    <p className="text-xs text-slate-600 leading-snug">
                                                        Es cuántas veces lee el modelo el libro entero (dataset). <strong>100 Iteraciones</strong> = lo leyó 100 veces. 
                                                        <br/><span className="text-slate-400 italic">Si son muchas, memoriza (overfitting); si son pocas, no aprende.</span>
                                                    </p>
                                                </div>
                                                
                                                <div>
                                                    <p className="text-xs font-bold text-pink-700 mb-1 flex items-center gap-1">
                                                        <Sigma size={12}/> ¿Por qué la curva S?
                                                    </p>
                                                    <p className="text-xs text-slate-600 leading-snug">
                                                        Porque predecimos <strong>Probabilidad</strong> (0 a 1). La "S" (Sigmoide) aplasta valores locos (ej: 1.5) para que siempre den un % válido.
                                                    </p>
                                                </div>

                                                <div>
                                                    <p className="text-xs font-bold text-blue-700 mb-1 flex items-center gap-1">
                                                        <Terminal size={12}/> ¿Qué es el Optimizador?
                                                    </p>
                                                    <p className="text-xs text-slate-600 leading-snug">
                                                        Es el método para encontrar la solución. <strong>liblinear</strong> es ideal para datasets pequeños.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="bg-blue-50 p-5 rounded-xl border border-blue-100">
                                             <h3 className="font-bold text-blue-900 mb-2 flex items-center gap-2 text-sm uppercase tracking-wider">
                                                <Briefcase size={16} />
                                                Conclusión Ejecutiva
                                            </h3>
                                            <p className="text-xs text-blue-800 leading-relaxed">
                                                "Matemáticamente, la lealtad se decide en la <strong>2da compra</strong>. El monto gastado es irrelevante para la clasificación."
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* DOWNLOAD CODE SECTION */}
                                <div className="bg-slate-900 p-8 rounded-xl border border-slate-800 shadow-xl flex justify-between items-center relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                        <FileCode size={120} className="text-white" />
                                    </div>
                                    <div className="relative z-10 max-w-xl">
                                        <h3 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
                                            <Terminal className="text-green-400" size={20} />
                                            Llévalo a Producción
                                        </h3>
                                        <p className="text-slate-400 text-sm">
                                            Esta simulación fue visual. Descarga el <strong>código Python real</strong> (Scikit-Learn) para ejecutarlo en tu VS Code y presentarlo.
                                        </p>
                                    </div>
                                    <button 
                                        onClick={downloadTrainingScript}
                                        className="relative z-10 bg-green-600 hover:bg-green-500 text-white px-6 py-3 rounded-lg font-bold text-sm shadow-lg shadow-green-900/50 transition-all flex items-center gap-2 whitespace-nowrap"
                                    >
                                        <Download size={18} />
                                        entrenamiento_modelo_aurelion.py
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                );
            case AppView.FEATURE_ENGINEERING:
                const loyalCount = rfmData.filter(d => d.is_fidelizado === 1).length;
                const occasionalCount = rfmData.length - loyalCount;
                const chartData = [
                    { name: 'Fieles (1)', value: loyalCount, fill: '#10b981' },
                    { name: 'Ocasionales (0)', value: occasionalCount, fill: '#64748b' },
                ];

                return (
                    <div className="space-y-6">
                         {/* Header y Controles */}
                         <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                            <div>
                                <h2 className="text-2xl font-bold text-slate-800">Ingeniería de Features (RFM)</h2>
                                <p className="text-slate-500 text-sm">Análisis visual de las variables predictoras</p>
                            </div>
                            
                            <div className="flex flex-wrap gap-2">
                                <button 
                                    onClick={() => setIsPresentationMode(!isPresentationMode)}
                                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center shadow-sm ${
                                        isPresentationMode 
                                        ? 'bg-slate-200 text-slate-800 hover:bg-slate-300 border border-slate-300' 
                                        : 'bg-slate-800 text-white hover:bg-slate-700'
                                    }`}
                                >
                                    {isPresentationMode ? <Minimize2 size={16} className="mr-2"/> : <Maximize2 size={16} className="mr-2"/>}
                                    {isPresentationMode ? 'Salir' : 'Pantalla Completa'}
                                </button>
                            </div>
                        </div>

                        {/* RESUMEN EJECUTIVO - TITLE CHANGED (REMOVED AI) */}
                        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 rounded-xl p-1 shadow-lg">
                            <div className="bg-white rounded-lg p-6">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="p-2 bg-indigo-100 rounded-lg">
                                            <Sparkles className="text-indigo-600" size={24} />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-bold text-slate-800">Resumen Ejecutivo</h3>
                                            <p className="text-xs text-slate-500">Generado por Gemini 2.5 Flash</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {insights && (
                                            <button
                                                onClick={downloadAIExecutiveSummary}
                                                className="text-xs bg-white/20 hover:bg-white/30 text-indigo-900 border border-indigo-200 px-3 py-2 rounded-md transition-colors flex items-center gap-2 font-medium"
                                                title="Descargar Resumen"
                                            >
                                                <Download size={14} />
                                            </button>
                                        )}
                                        <button 
                                            onClick={handleGenerateInsights}
                                            disabled={isGeneratingInsights}
                                            className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-md transition-colors flex items-center gap-2 font-medium disabled:opacity-50"
                                        >
                                            {isGeneratingInsights ? <Loader2 size={14} className="animate-spin"/> : <Sparkles size={14}/>}
                                            {insights ? 'Regenerar Reporte' : 'Generar Reporte'}
                                        </button>
                                    </div>
                                </div>

                                {insights ? (
                                    <div className="bg-slate-50 p-5 rounded-xl border border-slate-100 text-sm text-slate-700 prose prose-indigo max-w-none animate-in fade-in slide-in-from-top-2 duration-500">
                                        <div dangerouslySetInnerHTML={{ __html: insights.replace(/\n/g, '<br/>').replace(/### (.*?)<br\/>/g, '<h4 class="text-indigo-700 font-bold text-base mt-3 mb-1">$1</h4>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                                    </div>
                                ) : (
                                    <div className="bg-slate-50 border border-slate-100 border-dashed rounded-xl p-8 text-center">
                                        <p className="text-slate-500 text-sm mb-2">¿Necesitas un análisis rápido para tu presentación?</p>
                                        <button onClick={handleGenerateInsights} className="text-indigo-600 font-semibold text-sm hover:underline">
                                            Haz clic para generar insights automáticos de tus datos RFM
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>

                         {/* Gráficos Principales */}
                         <div className={`grid grid-cols-1 ${isPresentationMode ? 'lg:grid-cols-2 h-[60vh]' : 'lg:grid-cols-2'} gap-6`}>
                            <div id="chart-target-dist" className={`bg-white p-6 rounded-xl shadow-sm border border-slate-200 ${isPresentationMode ? 'flex flex-col' : ''}`}>
                                <div className="flex justify-between items-center mb-2">
                                    <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                                        <div className="w-2 h-6 bg-emerald-500 rounded-sm"></div>
                                        Distribución del Target
                                    </h2>
                                    <button
                                        onClick={() => downloadChartAsPng('chart-target-dist', 'grafico_distribucion_target')}
                                        className="bg-slate-100 hover:bg-slate-200 text-slate-600 p-1.5 rounded-lg transition-colors shadow-sm border border-slate-300"
                                        title="Descargar Imagen PNG"
                                    >
                                        <Camera size={16} />
                                    </button>
                                </div>
                                <p className="text-xs text-slate-500 mb-4">Proporción de clientes Fieles (1) vs Ocasionales (0)</p>
                                <ResponsiveContainer width="100%" height={isPresentationMode ? "100%" : 250}>
                                    <BarChart data={chartData} layout="vertical">
                                        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                                        <XAxis type="number" />
                                        <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                                        <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                        <Bar dataKey="value" name="Clientes" barSize={32} radius={[0, 4, 4, 0]} animationDuration={1500}>
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                            
                            <div id="chart-freq-spend" className={`bg-white p-6 rounded-xl shadow-sm border border-slate-200 ${isPresentationMode ? 'flex flex-col' : ''}`}>
                                <div className="flex justify-between items-center mb-2">
                                    <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                                        <div className="w-2 h-6 bg-blue-500 rounded-sm"></div>
                                        Patrón: Frecuencia vs Gasto
                                    </h2>
                                    <button
                                        onClick={() => downloadChartAsPng('chart-freq-spend', 'grafico_frecuencia_vs_gasto')}
                                        className="bg-slate-100 hover:bg-slate-200 text-slate-600 p-1.5 rounded-lg transition-colors shadow-sm border border-slate-300"
                                        title="Descargar Imagen PNG"
                                    >
                                        <Camera size={16} />
                                    </button>
                                </div>
                                <p className="text-xs text-slate-500 mb-4">Relación entre veces que compran y cuánto gastan</p>
                                <ResponsiveContainer width="100%" height={isPresentationMode ? "100%" : 250}>
                                    <ScatterChart margin={{top: 10, right: 10, bottom: 10, left: 0}}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                        <XAxis type="number" dataKey="frequency" name="Frecuencia" unit=" compras" label={{ value: 'Frecuencia', position: 'insideBottom', offset: -5, fontSize: 12 }} tick={{fontSize: 12}} />
                                        <YAxis type="number" dataKey="monetary" name="Monetario" unit=" $" label={{ value: 'Gasto ($)', angle: -90, position: 'insideLeft', fontSize: 12 }} tick={{fontSize: 12}} />
                                        <ZAxis type="number" dataKey="is_fidelizado" range={[50, 300]} name="Fidelidad" />
                                        <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                        
                                        {/* SEABORN STYLE: Blue with White Stroke */}
                                        <Scatter name="Clientes" data={rfmData} fill="#3b82f6" stroke="#ffffff" strokeWidth={2} animationDuration={1000} fillOpacity={0.8} />
                                    </ScatterChart>
                                </ResponsiveContainer>
                            </div>
                         </div>

                         {/* Tabla de Datos Colapsable */}
                         <div className={`bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden transition-all duration-500 ${isPresentationMode ? 'hidden' : ''}`}>
                            <div className="w-full p-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                                <div className="flex items-center gap-3 w-full sm:w-auto">
                                    <div className="bg-white p-2 rounded-md border border-slate-200 shadow-sm text-slate-500">
                                        <FileText size={18} />
                                    </div>
                                    <div className="text-left">
                                        <h3 className="text-sm font-bold text-slate-800">Dataset Procesado (RFM)</h3>
                                        <p className="text-xs text-slate-500">{rfmData.length} registros listos para el modelo</p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3">
                                    {/* CSV DOWNLOAD BUTTON - NOW ALWAYS VISIBLE */}
                                    <button 
                                        onClick={downloadCleanedMaster}
                                        className="flex items-center gap-2 bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-bold shadow-sm hover:bg-emerald-700 transition-colors"
                                    >
                                        <Download size={14} />
                                        Descargar CSV
                                    </button>

                                    <button 
                                        onClick={() => setIsTableExpanded(!isTableExpanded)}
                                        className="flex items-center gap-2 text-xs font-medium text-slate-600 bg-white px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
                                    >
                                        {isTableExpanded ? 'Ocultar Tabla' : 'Ver Datos'}
                                        {isTableExpanded ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}
                                    </button>
                                </div>
                            </div>
                            
                            {isTableExpanded && (
                                <div className="p-4 animate-in fade-in slide-in-from-top-5">
                                    <div className="overflow-x-auto max-h-96 custom-scrollbar rounded-lg border border-slate-200">
                                        <table className="min-w-full divide-y divide-slate-200 text-xs">
                                            <thead className="bg-slate-50 sticky top-0 z-10">
                                                <tr>
                                                    {['id_cliente', 'recency_days', 'frequency', 'monetary', 'categoria_preferida', 'is_fidelizado'].map(h => (
                                                        <th key={h} className="px-4 py-3 text-left font-semibold text-slate-600 uppercase tracking-wider">{h}</th>
                                                    ))}
                                                </tr>
                                            </thead>
                                            <tbody className="bg-white divide-y divide-slate-200">
                                                {rfmData.map((row) => (
                                                    <tr key={row.id_cliente} className={`hover:bg-slate-50 transition-colors ${row.is_fidelizado === 1 ? 'bg-green-50/30' : ''}`}>
                                                        <td className="px-4 py-2 font-mono text-slate-500">{row.id_cliente}</td>
                                                        <td className="px-4 py-2">{row.recency_days}</td>
                                                        <td className="px-4 py-2 font-bold text-slate-800">{row.frequency}</td>
                                                        <td className="px-4 py-2 text-emerald-600 font-medium">{formatCurrency(row.monetary)}</td>
                                                        <td className="px-4 py-2">
                                                            <span className="px-2 py-1 bg-slate-100 rounded text-slate-600 text-[10px] uppercase tracking-wide">
                                                                {row.categoria_preferida}
                                                            </span>
                                                        </td>
                                                        <td className="px-4 py-2">
                                                            <span className={`px-2 py-1 rounded-full text-[10px] font-bold border ${
                                                                row.is_fidelizado === 1 
                                                                ? 'bg-green-100 text-green-700 border-green-200' 
                                                                : 'bg-slate-100 text-slate-500 border-slate-200'
                                                            }`}>
                                                                {row.is_fidelizado === 1 ? 'FIEL (1)' : 'OCASIONAL (0)'}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}
                         </div>
                    </div>
                );
            default:
                return (
                    <div className="p-10 text-center text-slate-400">
                        <h3 className="text-xl font-semibold">Selecciona una opción del menú</h3>
                    </div>
                );
        }
    };

    return (
        <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900">
            {!isPresentationMode && (
                <Sidebar 
                    currentView={currentView} 
                    onChangeView={setCurrentView} 
                    setShowHelpModal={setShowHelpModal} 
                />
            )}
            <main className={`flex-1 ${isPresentationMode ? 'p-4' : 'ml-64 p-8'} overflow-y-auto h-screen transition-all duration-300`}>
                <div className={`mx-auto h-full ${isPresentationMode ? 'max-w-full' : 'max-w-6xl'}`}>
                    {renderContent()}
                </div>
            </main>

            {/* Modal de Ayuda Git MEJORADO */}
            {showHelpModal && (
                <div className="fixed inset-0 bg-slate-900/80 z-[100] flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowHelpModal(false)}>
                    <div className="bg-white rounded-2xl p-8 max-w-2xl w-full shadow-2xl transform transition-all" onClick={e => e.stopPropagation()}>
                        <div className="text-center mb-8">
                            <h3 className="text-2xl font-black text-slate-800 mb-2">¡NO PIERDAS TU TRABAJO!</h3>
                            <p className="text-slate-600">Sigue este mapa para encontrar el botón de guardar:</p>
                        </div>

                        <div className="relative bg-slate-100 border-2 border-slate-300 rounded-xl p-4 h-64 flex items-center justify-center mb-8 overflow-hidden">
                            {/* Representación Gráfica de la Pantalla */}
                            <div className="absolute left-0 top-0 bottom-0 w-8 bg-black flex flex-col items-center py-4 gap-2 z-20">
                                {/* Barra Lateral IDE */}
                                <div className="w-4 h-4 bg-gray-600 rounded-sm"></div>
                                <div className="w-4 h-4 bg-gray-600 rounded-sm"></div>
                                <div className="w-4 h-4 bg-gray-600 rounded-sm"></div>
                                <div className="w-4 h-4 bg-gray-600 rounded-sm"></div>
                                <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse ring-2 ring-blue-400 ring-offset-2 ring-offset-black"></div>
                            </div>
                            <div className="absolute left-8 top-0 bottom-0 w-48 bg-slate-800 z-10 flex items-center justify-center">
                                <span className="text-[10px] text-slate-500">Mi App (Azul)</span>
                            </div>
                            <div className="absolute left-56 top-0 bottom-0 right-0 bg-white flex items-center justify-center">
                                <span className="text-xs text-slate-400">Tu pantalla principal</span>
                            </div>

                            {/* Flecha indicadora */}
                            <div className="absolute left-12 top-1/2 translate-y-8 flex items-center animate-bounce">
                                <ArrowLeft className="text-red-600 w-12 h-12" strokeWidth={3} />
                                <div className="bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-r-lg shadow-lg">
                                    ¡BUSCA EL GATO! <br/> (Icono GitHub)
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="flex gap-4 items-start">
                                <div className="bg-slate-200 p-2 rounded-full font-bold text-slate-700">1</div>
                                <p className="text-sm text-slate-700 mt-1">
                                    Presiona <strong>Ctrl + S</strong> para quitar el aviso "Unsaved".
                                </p>
                            </div>
                            <div className="flex gap-4 items-start">
                                <div className="bg-slate-200 p-2 rounded-full font-bold text-slate-700">2</div>
                                <p className="text-sm text-slate-700 mt-1">
                                    Busca el <strong>icono de GitHub (el gato)</strong> en la barra negra izquierda.
                                </p>
                            </div>
                            <div className="flex gap-4 items-start">
                                <div className="bg-slate-200 p-2 rounded-full font-bold text-slate-700">3</div>
                                <p className="text-sm text-slate-700 mt-1">
                                    Escribe "Guardar cambios" y dale al botón azul.
                                </p>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t border-slate-200">
                            <h4 className="font-bold text-slate-800 mb-4 text-sm uppercase tracking-wider">Glosario de Botones (Barra Superior)</h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-blue-300 transition-colors">
                                    <div className="flex items-center gap-2 mb-1 text-blue-700 font-semibold">
                                        <Download size={16} /> <span>Download App</span>
                                    </div>
                                    <p className="text-xs text-slate-600 leading-snug">
                                        Baja todo el código a tu computadora como un <strong>.ZIP</strong>. Es tu copia de seguridad personal.
                                    </p>
                                </div>
                                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-purple-300 transition-colors">
                                    <div className="flex items-center gap-2 mb-1 text-purple-700 font-semibold">
                                        <Copy size={16} /> <span>Copy / Fork</span>
                                    </div>
                                    <p className="text-xs text-slate-600 leading-snug">
                                        Crea un <strong>duplicado</strong> de este proyecto en la nube. Útil para experimentar sin romper nada.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <button 
                            onClick={() => setShowHelpModal(false)}
                            className="w-full mt-8 bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-transform hover:scale-[1.02] shadow-lg shadow-blue-200"
                        >
                            ¡ENTENDIDO!
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default App;
