export interface SaleRecord {
    id_venta: number;
    fecha: string;
    id_cliente: number;
    cliente: string;
    email: string;
    ciudad: string;
    alta: string;
    id_producto: number;
    producto: string;
    categoria: string;
    cantidad: number;
    precio_unitario: number;
    importe: number;
    importe_std: number;
    medio_pago_efectivo: boolean;
    medio_pago_qr: boolean;
    medio_pago_tarjeta: boolean;
    medio_pago_transferencia: boolean;
    precio: number;
}

export interface RFMRecord {
    id_cliente: number;
    cliente: string;
    ciudad: string;
    recency_days: number;
    frequency: number;
    monetary: number;
    monetary_log: number;
    categoria_preferida: string;
    is_fidelizado: number; // 0 or 1
}

export enum AppView {
    CONTEXT = 'CONTEXT',
    DATA_PREP = 'DATA_PREP',
    FEATURE_ENGINEERING = 'FEATURE_ENGINEERING',
    MODEL_EXPLAINER = 'MODEL_EXPLAINER',
    MENTOR = 'MENTOR',
    PYTHON_CODE = 'PYTHON_CODE'
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}